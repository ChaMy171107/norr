# Giữ nguyên các lớp cần thiết nếu bật minify sau này.
-keep class com.mpatric.mp3agic.** { *; }
